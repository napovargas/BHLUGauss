'BHLU'      = function(X, Z, priormean, priorvar, df, Iterations, burn, thin = 1, spp_names){
  n  = dim(Z)[1]
  r1 = dim(Z)[2]
  p  = dim(X)[2]
  r2 = dim(X)[1]
  p2 = length(priormean)
  p3 = dim(priorvar)[1]
  p4 = dim(priorvar)[2]
  
  if(n < r1){
    stop(cat('Number of observations :', n, ' should be at least equal to the number of markers: ', r1, '\n'))
  }
  if(r1 != r2){
    stop(cat('Number of markers in response: ', r1, 'does not match number of markers in source: ', r2, '\n'))
  }
  if(p2 != p){
    stop(cat('Prior mean vector has: ', p2, 'elements while source matrix has: ', p,' elements\n'))
  }
  if((p3 != p) | (p3 != p2) | (p3 != p4)){
    stop(cat('Dimensions of prior mean vector and prior mean variance matrix do not match\n'))
  }
  if(Iterations < 2){
    stop(cat('Number of iterations should be greater than 1\n'))
  }
  if(burn > Iterations){
    stop(cat('Number of iterations should be greater than number of burn-in rounds\n'))
  }
  if(df < (p3 + 2)){
    stop(cat('Prior degrees of freedom should be at least ', p3 + 2, "\n"))
  }
  if(length(spp_names) != p){
    stop(cat('Number of column names should equal number of columns'))
  }
  cat('-------------------------------------\n')
  cat('Bayesian hierarchical linear unmixing\n')
  cat('-------------------------------------\n')
  M               = X
  Y               = t(Z)
  q               = priormean
  V               = priorvar
  nu              = df
  nIter           = Iterations
  burnIn          = burn
  thin            = thin
  fit             = BHUgauss(M, Y, q, V, nu, nIter)
  Temp            = fit$Theta
  thining         = seq(burnIn + 1, nIter, by = thin)
  Theta           = Temp[thining , ,]
  Means           = t(colMeans(Theta))
  colnames(Means) = spp_names
  return(list('Theta' = Theta, 'Means' = Means))
}

'KSI'       = function(Thetahat, Theta){
  p         = ncol(Thetahat)
  n         = nrow(Thetahat)
  KSI       = numeric(n)
  for(i in 1:n){
    tmp = 0
    for(j in 1:p){
      tmp = tmp + 2*min(Thetahat[i, j], Theta[i, j])
    }
    KSI[i] = tmp/(sum(Thetahat[i, ] + Theta[i, ]))
  }
  return(as.matrix(KSI))
}

"nnlsWax"   = function(M, Y){
  library(nnls)
  Tmp   = apply(Y, 2, function(Y.col) nnls(M, Y.col)$x)
  Theta = apply(Tmp, 2, function(Tmp.col) Tmp.col/sum(Tmp.col)) 
  return(Theta)
}

'mse'       = function(thetahat, theta){
  n         = length(thetahat)
  mse       = (1/n)*sum((thetahat - theta)^2)
  return(mse)
}

'rmse'     = function(thetahat, theta){
  n        = length(thetahat)
  rmse     = (1/n)*sum(((thetahat - theta)/theta)^2)
  return(rmse)
}

'nmse'      = function(Est, Tru){
  Out = norm(Est - Tru, type = "E")/norm(Est, type = 'E')
  return(Out)
}

"re"        = function(Y, M, thetahat){
  n = ncol(Y)
  Theta = t(thetahat)
  Residual = array(0, dim = c(n, 1))
  for(i in 1:n){
    Residual[i] = norm(Y[,i] - M%*%Theta[,i], "E")
  }
  re = sqrt((1/n)*sum(Residual))
  return(re)
}